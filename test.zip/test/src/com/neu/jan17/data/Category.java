package com.neu.jan17.data;

public enum Category {
	NEW, CERTIFIED, USED
}
