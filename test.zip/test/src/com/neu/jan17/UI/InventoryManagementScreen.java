package com.neu.jan17.UI;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;

import com.neu.jan17.data.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

public class InventoryManagementScreen extends JFrame {


    private JPanel totalPanel;
    private JPanel topPanel;
    private JPanel midPanel;
    private JPanel bottomPanel;
    private JTable inventoryData;
    private JScrollPane inventoryPane;
    private JLabel dealerNameLabel;
    private JComboBox dealerItem;
    private JButton selectDealer;
    private JButton addButton;
    private JButton updateButton;

    protected Vehicles ve;

    public InventoryManagementScreen() {

        Vector<Vehicle> vehicleData = new Vector<>();

        dealerNameLabel = new JLabel("Please choose a dealer:");

        DealerData dd = new DealerData();
        String[] dealerID = new String[dd.getDealersData().length];
        for (int i = 0; i < dd.getDealersData().length; i++) {
            dealerID[i] = dd.getDealersData()[i].getId().substring(5, dd.getDealersData()[i].getId().length());
        }
        dealerItem = new JComboBox(dealerID);

        ve = new Vehicles();

        inventoryData = new JTable(new dealerModel(ve));
        inventoryData.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = ((JTable) e.getSource()).rowAtPoint(e.getPoint());
                    openEditUI(ve.showData(row), row);
                } else {
                    return;
                }
            }
        });
        inventoryData.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        inventoryPane = new JScrollPane(inventoryData);

        selectDealer = new JButton("Confirm");
        selectDealer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String getDealerID = "";
                getDealerID += "gmps-" + dealerItem.getSelectedItem();
                try {
                    ve.removeAll();
                    for (Vehicle v : getVehicle(getDealerID).getVehicles()) {
                        ve.addData(v);
                    }
                    repaint();
                } catch (Exception uknowne) {
                }
            }
        });
        addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAddUI();
            }
        });
        updateButton = new JButton("Update");

        topPanel = new JPanel();
        midPanel = new JPanel();
        bottomPanel = new JPanel();
        topPanel.add(dealerNameLabel);
        topPanel.add(dealerItem);
        topPanel.add(selectDealer);
        midPanel.add(inventoryPane);
        bottomPanel.add(addButton);
        bottomPanel.add(updateButton);

        Font f1 = new Font("Meiryo UI", Font.PLAIN, 12);
        inventoryData.setRowHeight(30);
        inventoryData.setAutoCreateRowSorter(true);
        inventoryData.setGridColor(Color.BLUE);
        //inventoryPane.setSize(800, 500);

        Container con = getContentPane();
        setLayout(new BorderLayout(2, 2));
        con.add("North", topPanel);
        con.add("Center", midPanel);
        con.add("South", bottomPanel);
        changeFont(con, f1);
        setVisible(true);
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


    }

    public Inventory getVehicle(String id) throws Exception {
        InventoryManagerInterface imi = new InventoryManager("data");
        Inventory inventory = imi.getInventoryByDealerId(id);
        return inventory;
    }

    public void openAddUI() {
        new AddVehicle(this);
    }

    public void openEditUI(Vehicle vehicle, int row) {
        new AddVehicle(this, vehicle, row);
    }

    public void changeFont(Component component, Font font) {

        component.setFont(font);
        if (component instanceof Container) {
            for (Component child : ((Container) component).getComponents()) {
                changeFont(child, font);
            }
        }
    }

    class Vehicles {

        Vector<Vehicle> data = new Vector<>();

        Vehicles() {
        }

        public void addData(Vehicle vehicle) {
            data.add(vehicle);
        }

        public Vehicle showData(int row) {
            return data.get(row);
        }

        public void removeData(int row){
            data.remove(row);
        }

        public void removeAll() {
            data.removeAllElements();
        }

        public void changeData(int row, Vehicle vehicle) {
            data.set(row, vehicle);
        }

    }

    class dealerModel extends AbstractTableModel {

        private Vehicles vehicle;
        private String[] name = {"Id", "Category", "Year", "Make", "Model", "Bodytype", "Price",};

        dealerModel(Vehicles vehicle) {
            this.vehicle = vehicle;
        }

        public int getRowCount() {
            return vehicle.data.size();
        }

        public int getColumnCount() {
            return 7;
        }

        public Object getValueAt(int row, int col) {
            Vehicle veh = vehicle.showData(row);
            if (col == 0) {
                return veh.getId();
            } else if (col == 1) {
                return veh.getCategory();
            } else if (col == 2) {
                return veh.getYear();
            } else if (col == 3) {
                return veh.getMake();
            } else if (col == 4) {
                return veh.getModel();
            } else if (col == 5) {
                return veh.getBodyType();
            } else {
                return veh.getPrice();
            }
        }

        public String getColumnName(int colIndex) {
            return name[colIndex];
        }

        public Class getColumnClass(int c) {
            return String.class;
        }

        public boolean isCellEditable(int row, int col) {
            return false;
        }

        public void setValueAt(String aValue, int row, int col) {

        }
    }

    public static void main(String[] args) {


        new InventoryManagementScreen();
    }
}
